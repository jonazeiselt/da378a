#include <iostream>
#include "constants.h"

int main(int argc, char** argv)
{
	std::cout << "PI = " << PI << std::endl;

	return 0;
}