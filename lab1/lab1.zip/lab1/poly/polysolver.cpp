#include <iostream>
#include "poly2.h"

int main(int argc, char** argv)
{
	std::cout << "Root-finding started..." << std::endl;

    
    // todo

    
	return 0;
}